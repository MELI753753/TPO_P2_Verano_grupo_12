package org.example.util;

public class DictionaryUtil {
}
