package org.example.model;

public interface Queue {
    int getFirst();
    boolean isEmpty();
    void add(int a);
    void remove();
}
